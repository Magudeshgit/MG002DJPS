# MGReck
MGReck is a inventory management application built to manage inventory data effortlessely
